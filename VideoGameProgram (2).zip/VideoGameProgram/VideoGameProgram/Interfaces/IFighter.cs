﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace VideoGameProgram.Interfaces
{
    public interface IFighter
    {
        // this property must be aded to any class that uses the IFighter interface
        int CriticalHit { get; set; }
        // this method must be built in any class that uses IFighter Interface
        string Defend();
    }
}
