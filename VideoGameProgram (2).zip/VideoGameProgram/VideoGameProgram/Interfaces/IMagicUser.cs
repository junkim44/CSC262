﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VideoGameProgram.Interfaces
{
    public interface IMagicUser
    {
        // any class that implements this interface, must include the Mana property
        int Mana { get; set; }

        // any class that implements this interface, must include the CastSpell method
        string CastSpell(string spell);
    }
}
