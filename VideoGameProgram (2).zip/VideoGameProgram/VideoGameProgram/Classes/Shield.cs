﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VideoGameProgram.Classes
{
    public class Shield
    {
        public string Name { get; set; }
        public int Protection { get; set; }
        public bool Deflection {  get; set; }
        public int MeleeDefense { get; set;  }

        public Shield (string name, int protection, bool deflection, int meleeDefense)
        {
            Name = name;
            Protection = protection;
            Deflection = deflection;
            MeleeDefense = meleeDefense;
        }

        public bool TryDefelction()
        {
            // generate a random number and based on that return true or false if the deflection happened or not.
            return true;
        }
    }
}
