﻿using System;
using System.Collections.Generic;
using System.Text;
using VideoGameProgram.Interfaces;

namespace VideoGameProgram.Classes
{
    // Try to get the wizard working.
    public class Wizard : Character, IMagicUser
    {
        // Getter and setter for mana and spells
        public int Mana { get; set; }
        public List<string> Spells { get; set; }

        // constructor for Wizard
        public Wizard(string name, int health, List<string> inventory, int attack, int speed, int defense, int mana, List<string> spells) :
            base(name, health, inventory, attack, speed, defense)
        {
            Mana = mana;
            Spells = spells;
        }

        // override display method from Character base class to include Mana
        public override string Display()
        {
            // TODO : should we add inventory or should we make it a separate method
            return $"Character: {Name} has {Health} health with {Attack} Attack, {Speed} Speed, and {Defense} Defense and {Mana} Mana";
        }
        // overloaded display method that is described in the assignment requirements for week3
        public override string Display(int num)
        {
            if (num == 1)
            {
                return $"Character: {Name} has {Health} health with {Attack} Attack, {Speed} Speed, and {Defense} Defense, and {Mana} Mana";
            }
            else if (num == 2)
            {
                return $"Character: {Name} has {Health} health";
            }
            else if (num == 3)
            {
                return $"Character: {Name} has {Health} health with {Mana} Mana";
            } 
            else
            {
                return $"Character: {Name} has {Health} health with {Attack} Attack, {Speed} Speed, and {Defense} Defense, and {Mana} Mana";
            }

        }

        // Must include battle method because it's an abstract method
        public override string Battle(bool hitLanded, int damage)
        {
            // if the hit was successful, then reduce the health
            if (hitLanded)
            {
                Health = Health - damage - 5; // Wizard takes extra damage but they're sturdier than mages
            }
            return $"Health is now {Health}";
        }
        // must include castSpell method from the interface IMagicUser
        public string CastSpell(string spell)
        {
            return $"{spell} has been cast!"; // make this different from mage
        }
    }
}
