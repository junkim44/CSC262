﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Text;
using VideoGameProgram.Interfaces;

namespace VideoGameProgram.Classes
{
    // define the subclass and add : Character so Warrior can use all of the features of the Character class
    public class Warrior : Character, IFighter
    {
        // the shortcut way of creating the getter and setter methods - if you don't need to do any validation
        public int Power { get; set; }
        // this is the property that IFighter is making us add
        public int CriticalHit { get; set; }
        // this is composition, the warrior is not a shield - the warrior is a character, the warrior has a shield
        // inheritance "is a" composition "has a"
        public Shield EquippedShield { get; set; }

        public Warrior (string name, int health, List<string> inventory, int attack, int speed, int defense, int power) : 
            base(name, health, inventory, attack, speed, defense)
        {
            // we only need to set the power value here because we call the Character constructor with the base() line of code
            Power = power;

            // in our game rules, lets say that we give each warrior the same default shield when they start
            EquippedShield = new Shield("Paper Shield", 1, false, 0);
        }

        public string PowerBoost(int morePower)
        {
            Power += morePower;

            return $"{Name} now has {Power}";
        }
        // in the base class, optionally, if necessary, we can make our own version of the virtual methods from the base class
        // so in this case, we will create new versions of the Display Methods
        // base class - keyword: virtual; subclass - keyword: override
        public override string Display()
        {
            // TODO : should we add inventory or should we make it a separate method
            return $"Character: {Name} has {Health} health with {Attack} Attack, {Speed} Speed, and {Defense} Defense and {Power} Power";
        }

        // overloaded display method that is described in the assignment requirements for week 3
        public override string Display(int num)
        {
            if (num == 1)
            {
                return $"Character: {Name} has {Health} health with {Attack} Attack, {Speed} Speed, and {Defense} Defense and {Power} Power";
            }
            else if (num == 2)
            {
                return $"Character: {Name} has {Health} health";
            }
            else if (num == 3)
            {
                return $"Character: {Name} has {Health} health with {Power} Power";
            } 
            else
            {
                return $"Character: {Name} has {Health} health with {Attack} Attack, {Speed} Speed, and {Defense} Defense and {Power} Power";
            }

        }
        // because Battle is an abstract method, we must create that method in any of the Character subclasses
        public override string Battle(bool hitLanded, int damage)
        {
            // if the hit was successful, then reduce the health
            if (hitLanded)
            {
                Health = Health - damage + 2; // Warrior takes less damage
            }
            return $"Health is now {Health}";
        }

        public string Defend()
        {
            return "The character defended against the hit";
        }
    }
}
