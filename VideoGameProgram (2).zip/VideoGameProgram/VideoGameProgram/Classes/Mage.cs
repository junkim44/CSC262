﻿using System;
using System.Collections.Generic;
using System.Text;
using VideoGameProgram.Interfaces;
namespace VideoGameProgram.Classes
{
    public class Mage : Character, IMagicUser
    {
        // the shortcut way of creating the getter and setter methods - if you don't need to do any validation
        public int Mana { get; set; }
        public List<string> Spells { get; set; }
        public Mage(string name, int health, List<string> inventory, int attack, int speed, int defense, int mana, List<string> spells) :
            base(name, health, inventory, attack, speed, defense)
        {
            Mana = mana;
            Spells = spells;
        }
        // in the base class, optionally, if necessary, we can make our own version of the virtual methods from the base class
        // so in this case, we will create new versions of the Display Methods
        // base class - keyword: virtual; subclass - keyword: override
        public override string Display()
        {
            // TODO : should we add inventory or should we make it a separate method
            return $"Character: {Name} has {Health} health with {Attack} Attack, {Speed} Speed, and {Defense} Defense and {Mana} Mana";
        }

        // overloaded display method that is described in the assignment requirements for week3
        public override string Display(int num)
        {
            if (num == 1)
            {
                return $"Character: {Name} has {Health} health with {Attack} Attack, {Speed} Speed, and {Defense} Defense, and {Mana} Mana";
            }
            else if (num == 2)
            {
                return $"Character: {Name} has {Health} health";
            }
            else if (num == 3)
            {
                return $"Character: {Name} has {Health} health with {Mana} Mana";
            } 
            else
            {
                return $"Character: {Name} has {Health} health with {Attack} Attack, {Speed} Speed, and {Defense} Defense, and {Mana} Mana";
            }

        }

        // because Battle is an abstract method, we must create that method in any of the Character subclasses
        public override string Battle(bool hitLanded, int damage)
        {
            // if the hit was successful, then reduce the health
            if (hitLanded)
            {
                Health = Health - damage - 10; // Mages take extra damage
            }
            return $"Health is now {Health}";
        }

        // add the CastSpell method because we implement the IMagicUser interface and it makes us create that method
        public string CastSpell(string spell)
        {
            return $"{spell} has been cast!";
        }
    }
      

}
