﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VideoGameProgram.Classes
{
    // so now the Character class is abstract
    public abstract class Character // cannot create object from Character Class but can create object from subclasses
        // Character class now becomes higher entity where it just becomes super blueprint, all of the logic will come from subclasses
    {
        // Private local variables
        private string name; // for private properties, use lowercase for the variable name and for public, use capital for the variable name
        private int health;
        private List<string> inventory;
        private int attack;
        private int speed;
        private int defense;

        // public properties
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int Health
        {
            get { return health;}
            set { 
                // in the set, we can add our data protection rules so that we don't end up
                // with invalid data set on our properties
                    if (value >= 0)
                    {
                        health = value;
                    }
                }
        }

        public List<string> Inventory
        {
            get { return inventory; }
            set { inventory = value; }
        }
        public int Attack
        {
            get { return attack; }
            set { attack = value; }
        }
        public int Speed
        {
            get { return speed; }
            set { speed = value; }
        }
        public int Defense
        {
            get { return defense; }
            set { defense = value; }
        }

        // the C# property set up shortcut
        //public string Middle_Name { get; set; }

        // build the constructor - this allows us to quickly create a Character object
        public Character(string name, int health, List<string> inventory, int attack, int speed, int defense)
        {
            // change the value of the local class variable to the value passed into the constructor
            Name = name; // this is the style that you will see most commonly in existing code bases
            // you can also name the variables in constructor something different like new_name, to make it easier to keep track
            Health = health; // you can set up the object to use the property so you get the data protection
            // this.health = heatlh can be done as well, but you lose the check to see if health is 0 or more
            Inventory = inventory;
            Attack = attack;
            Speed = speed;
            Defense = defense;
        }

        public Character(string name, int health, int attack, int speed, int defense)
        {
            // change the value of the local class variable to the value passed into the constructor
            Name = name; // this is the style that you will see most commonly in existing code bases
            // you can also name the variables in constructor something different like new_name, to make it easier to keep track
            Health = health; // you can set up the object to use the property so you get the data protection
            // this.health = heatlh can be done as well, but you lose the check to see if health is 0 or more
            Inventory = inventory;
            Attack = attack;
            Speed = speed;
            Defense = defense;
        }

        public abstract string Battle(bool isLanded, int Damage);

        // overloading - the methods have the same name, but different arguments or parameters
        public virtual string Display()
        {
            // TODO : should we add inventory or should we make it a separate method
            return $"Character: {Name} has {Health} health with {Attack} Attack, {Speed} Speed, and {Defense} Defense";
        }

        // overloaded display method that is described in the assignment requirements for week3
        public virtual string Display(int num)
        {
            if (num == 1)
            {
                return $"Character: {Name} has {Health} health with {Attack} Attack, {Speed} Speed, and {Defense} Defense";
            }
            else if (num == 2)
            {
                return $"Character: {Name} has {Health} health";
            }
            else if (num == 3)
            {
                return $"Character: {Name} has {Health} health with {Attack} Attack";
            }
            else
            {
                return $"Character: {Name} has {Health} health with {Attack} Attack, {Speed} Speed, and {Defense} Defense";
            }

        }
        // let's overload some health methods
        // health will be hardcoded to 100
        public string Heal()
        {
            Health = 100;
            return $"{Name} has been fully healed";
        }

        //health will be set to the number passed in 
        public string Heal(int num)
        {
            Health = num; ;
            return $"{Name} has been healed to {num}";
        }
    }
}
