﻿namespace VideoGameProgram
{
    partial class frmCharacterView
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCreate = new Button();
            lblCharacterInfo = new Label();
            lblName = new Label();
            lblHealth = new Label();
            lblInventory = new Label();
            lblAttack = new Label();
            lblSpeed = new Label();
            txtName = new TextBox();
            lblDefense = new Label();
            txtInventory = new TextBox();
            numHealth = new NumericUpDown();
            numAttack = new NumericUpDown();
            numSpeed = new NumericUpDown();
            numDefense = new NumericUpDown();
            lbCharacters = new ListBox();
            lbInventory = new ListBox();
            lblCharacter = new Label();
            lblCharacterInventory = new Label();
            pnlCharacter = new Panel();
            numSpec1 = new NumericUpDown();
            lblSpec1 = new Label();
            lblType = new Label();
            cmbType = new ComboBox();
            pnlStats = new Panel();
            btnDisplay = new Button();
            txtDisplayOption = new TextBox();
            lblDisplayOption = new Label();
            ((System.ComponentModel.ISupportInitialize)numHealth).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numAttack).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numSpeed).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numDefense).BeginInit();
            pnlCharacter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numSpec1).BeginInit();
            pnlStats.SuspendLayout();
            SuspendLayout();
            // 
            // btnCreate
            // 
            btnCreate.Location = new Point(40, 313);
            btnCreate.Name = "btnCreate";
            btnCreate.Size = new Size(132, 29);
            btnCreate.TabIndex = 0;
            btnCreate.Text = "Create";
            btnCreate.UseVisualStyleBackColor = true;
            btnCreate.Click += btnCreate_Click;
            // 
            // lblCharacterInfo
            // 
            lblCharacterInfo.AutoSize = true;
            lblCharacterInfo.Location = new Point(135, 368);
            lblCharacterInfo.Name = "lblCharacterInfo";
            lblCharacterInfo.Size = new Size(0, 15);
            lblCharacterInfo.TabIndex = 1;
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(44, 71);
            lblName.Name = "lblName";
            lblName.Size = new Size(39, 15);
            lblName.TabIndex = 2;
            lblName.Text = "Name";
            // 
            // lblHealth
            // 
            lblHealth.AutoSize = true;
            lblHealth.Location = new Point(41, 108);
            lblHealth.Name = "lblHealth";
            lblHealth.Size = new Size(42, 15);
            lblHealth.TabIndex = 3;
            lblHealth.Text = "Health";
            // 
            // lblInventory
            // 
            lblInventory.AutoSize = true;
            lblInventory.Location = new Point(40, 142);
            lblInventory.Name = "lblInventory";
            lblInventory.Size = new Size(57, 15);
            lblInventory.TabIndex = 4;
            lblInventory.Text = "Inventory";
            // 
            // lblAttack
            // 
            lblAttack.AutoSize = true;
            lblAttack.Location = new Point(40, 179);
            lblAttack.Name = "lblAttack";
            lblAttack.Size = new Size(41, 15);
            lblAttack.TabIndex = 5;
            lblAttack.Text = "Attack";
            // 
            // lblSpeed
            // 
            lblSpeed.AutoSize = true;
            lblSpeed.Location = new Point(40, 213);
            lblSpeed.Name = "lblSpeed";
            lblSpeed.Size = new Size(39, 15);
            lblSpeed.TabIndex = 6;
            lblSpeed.Text = "Speed";
            // 
            // txtName
            // 
            txtName.Location = new Point(111, 63);
            txtName.Name = "txtName";
            txtName.Size = new Size(107, 23);
            txtName.TabIndex = 7;
            // 
            // lblDefense
            // 
            lblDefense.AutoSize = true;
            lblDefense.Location = new Point(40, 247);
            lblDefense.Name = "lblDefense";
            lblDefense.Size = new Size(49, 15);
            lblDefense.TabIndex = 8;
            lblDefense.Text = "Defense";
            // 
            // txtInventory
            // 
            txtInventory.Location = new Point(111, 134);
            txtInventory.Name = "txtInventory";
            txtInventory.Size = new Size(107, 23);
            txtInventory.TabIndex = 9;
            // 
            // numHealth
            // 
            numHealth.Location = new Point(111, 100);
            numHealth.Name = "numHealth";
            numHealth.Size = new Size(107, 23);
            numHealth.TabIndex = 10;
            // 
            // numAttack
            // 
            numAttack.Location = new Point(111, 171);
            numAttack.Name = "numAttack";
            numAttack.Size = new Size(107, 23);
            numAttack.TabIndex = 11;
            // 
            // numSpeed
            // 
            numSpeed.Location = new Point(111, 205);
            numSpeed.Name = "numSpeed";
            numSpeed.Size = new Size(107, 23);
            numSpeed.TabIndex = 12;
            // 
            // numDefense
            // 
            numDefense.Location = new Point(111, 239);
            numDefense.Name = "numDefense";
            numDefense.Size = new Size(107, 23);
            numDefense.TabIndex = 13;
            // 
            // lbCharacters
            // 
            lbCharacters.FormattingEnabled = true;
            lbCharacters.Location = new Point(10, 29);
            lbCharacters.Name = "lbCharacters";
            lbCharacters.Size = new Size(489, 109);
            lbCharacters.TabIndex = 14;
            lbCharacters.SelectedIndexChanged += lbCharacters_SelectedIndexChanged;
            // 
            // lbInventory
            // 
            lbInventory.FormattingEnabled = true;
            lbInventory.Location = new Point(10, 178);
            lbInventory.Name = "lbInventory";
            lbInventory.Size = new Size(229, 109);
            lbInventory.TabIndex = 15;
            // 
            // lblCharacter
            // 
            lblCharacter.AutoSize = true;
            lblCharacter.Location = new Point(10, 6);
            lblCharacter.Name = "lblCharacter";
            lblCharacter.Size = new Size(63, 15);
            lblCharacter.TabIndex = 16;
            lblCharacter.Text = "Characters";
            // 
            // lblCharacterInventory
            // 
            lblCharacterInventory.AutoSize = true;
            lblCharacterInventory.Location = new Point(10, 149);
            lblCharacterInventory.Name = "lblCharacterInventory";
            lblCharacterInventory.Size = new Size(119, 15);
            lblCharacterInventory.TabIndex = 17;
            lblCharacterInventory.Text = "Character's Inventory";
            // 
            // pnlCharacter
            // 
            pnlCharacter.Controls.Add(numSpec1);
            pnlCharacter.Controls.Add(lblSpec1);
            pnlCharacter.Controls.Add(lblType);
            pnlCharacter.Controls.Add(cmbType);
            pnlCharacter.Controls.Add(numDefense);
            pnlCharacter.Controls.Add(numSpeed);
            pnlCharacter.Controls.Add(numAttack);
            pnlCharacter.Controls.Add(numHealth);
            pnlCharacter.Controls.Add(txtInventory);
            pnlCharacter.Controls.Add(lblDefense);
            pnlCharacter.Controls.Add(txtName);
            pnlCharacter.Controls.Add(lblSpeed);
            pnlCharacter.Controls.Add(lblAttack);
            pnlCharacter.Controls.Add(lblInventory);
            pnlCharacter.Controls.Add(lblHealth);
            pnlCharacter.Controls.Add(lblName);
            pnlCharacter.Controls.Add(btnCreate);
            pnlCharacter.Location = new Point(24, 41);
            pnlCharacter.Name = "pnlCharacter";
            pnlCharacter.Size = new Size(233, 373);
            pnlCharacter.TabIndex = 18;
            // 
            // numSpec1
            // 
            numSpec1.Location = new Point(110, 276);
            numSpec1.Name = "numSpec1";
            numSpec1.Size = new Size(108, 23);
            numSpec1.TabIndex = 17;
            numSpec1.Visible = false;
            // 
            // lblSpec1
            // 
            lblSpec1.AutoSize = true;
            lblSpec1.Location = new Point(41, 284);
            lblSpec1.Name = "lblSpec1";
            lblSpec1.Size = new Size(0, 15);
            lblSpec1.TabIndex = 16;
            // 
            // lblType
            // 
            lblType.AutoSize = true;
            lblType.Location = new Point(44, 32);
            lblType.Name = "lblType";
            lblType.Size = new Size(32, 15);
            lblType.TabIndex = 15;
            lblType.Text = "Type";
            // 
            // cmbType
            // 
            cmbType.FormattingEnabled = true;
            cmbType.Items.AddRange(new object[] { "Mage", "Warrior", "Wizard" });
            cmbType.Location = new Point(97, 29);
            cmbType.Name = "cmbType";
            cmbType.Size = new Size(121, 23);
            cmbType.TabIndex = 14;
            cmbType.SelectedIndexChanged += cmbType_SelectedIndexChanged;
            // 
            // pnlStats
            // 
            pnlStats.Controls.Add(btnDisplay);
            pnlStats.Controls.Add(txtDisplayOption);
            pnlStats.Controls.Add(lblDisplayOption);
            pnlStats.Controls.Add(lblCharacterInventory);
            pnlStats.Controls.Add(lblCharacter);
            pnlStats.Controls.Add(lbInventory);
            pnlStats.Controls.Add(lbCharacters);
            pnlStats.Location = new Point(272, 41);
            pnlStats.Name = "pnlStats";
            pnlStats.Size = new Size(516, 373);
            pnlStats.TabIndex = 19;
            // 
            // btnDisplay
            // 
            btnDisplay.Location = new Point(129, 324);
            btnDisplay.Name = "btnDisplay";
            btnDisplay.Size = new Size(75, 23);
            btnDisplay.TabIndex = 20;
            btnDisplay.Text = "Display";
            btnDisplay.UseVisualStyleBackColor = true;
            btnDisplay.Click += btnDisplay_Click;
            // 
            // txtDisplayOption
            // 
            txtDisplayOption.Location = new Point(10, 325);
            txtDisplayOption.Name = "txtDisplayOption";
            txtDisplayOption.Size = new Size(100, 23);
            txtDisplayOption.TabIndex = 19;
            // 
            // lblDisplayOption
            // 
            lblDisplayOption.AutoSize = true;
            lblDisplayOption.Location = new Point(10, 302);
            lblDisplayOption.Name = "lblDisplayOption";
            lblDisplayOption.Size = new Size(140, 15);
            lblDisplayOption.TabIndex = 18;
            lblDisplayOption.Text = "Display Option (1, 2, or 3)";
            // 
            // frmCharacterView
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pnlStats);
            Controls.Add(pnlCharacter);
            Controls.Add(lblCharacterInfo);
            Name = "frmCharacterView";
            Text = "Manage Video Game Characters";
            ((System.ComponentModel.ISupportInitialize)numHealth).EndInit();
            ((System.ComponentModel.ISupportInitialize)numAttack).EndInit();
            ((System.ComponentModel.ISupportInitialize)numSpeed).EndInit();
            ((System.ComponentModel.ISupportInitialize)numDefense).EndInit();
            pnlCharacter.ResumeLayout(false);
            pnlCharacter.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numSpec1).EndInit();
            pnlStats.ResumeLayout(false);
            pnlStats.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCreate;
        private Label lblCharacterInfo;
        private Label lblName;
        private Label lblHealth;
        private Label lblInventory;
        private Label lblAttack;
        private Label lblSpeed;
        private TextBox txtName;
        private Label lblDefense;
        private TextBox txtInventory;
        private NumericUpDown numHealth;
        private NumericUpDown numAttack;
        private NumericUpDown numSpeed;
        private NumericUpDown numDefense;
        private ListBox lbCharacters;
        private ListBox lbInventory;
        private Label lblCharacter;
        private Label lblCharacterInventory;
        private Panel pnlCharacter;
        private Panel pnlStats;
        private Label lblType;
        private ComboBox cmbType;
        private NumericUpDown numSpec1;
        private Label lblSpec1;
        private Label lblDisplayOption;
        private TextBox txtDisplayOption;
        private Button btnDisplay;
    }
}
