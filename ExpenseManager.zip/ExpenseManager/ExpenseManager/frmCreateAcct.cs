﻿using ExpenseManager.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ExpenseManager
{
    public partial class frmCreateAcct : Form
    {
        public frmCreateAcct()
        {
            InitializeComponent();
        }
        private void btnCreateAcct_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate user input using exceptions
                if (string.IsNullOrWhiteSpace(txtUsername.Text) || string.IsNullOrWhiteSpace(txtPassword.Text) || string.IsNullOrWhiteSpace(txtEmail.Text)
                    || string.IsNullOrWhiteSpace(txtFName.Text) || string.IsNullOrWhiteSpace(txtLName.Text))
                {
                    lblCAMessage.Text = "Please fill out all fields.";
                    return;
                }
                // check to see if the username exists already
                if (Account.UsernameExists(txtUsername.Text))
                {
                    lblCAMessage.Text = "Username already taken. Please choose another one.";
                    return;
                }

                // create account object
                Account newAccount = new Account(

                    username: txtUsername.Text,
                    password: txtPassword.Text,
                    email: txtEmail.Text
                    );
                // Insert new account into account table in database
                int newAccountID = Account.CreateAccount(newAccount);

                // Create UserProfile object
                UserProfile newProfile = new UserProfile(
                    firstName: txtFName.Text,
                    lastName: txtLName.Text
                    );
                // insert new profile into table in database
                UserProfile.CreateProfile(newProfile, newAccountID);

                // Show success message if profile and account created
                lblCAMessage.Text = "Account created successfully, please log in.";
                frmLogIn frmLogIn = new frmLogIn();
                frmLogIn.Show();
                this.Hide();
            }
            catch(Exception ex)
            {
                lblCAMessage.Text = $"Error creating account: {ex.Message}";
            }
        }
    }
}
