﻿namespace ExpenseManager
{
    partial class frmCompanies
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listView1 = new ListView();
            lblCurrentCompanies = new Label();
            lblAddCompany = new Label();
            txtCompanyName = new TextBox();
            lblCompanyName = new Label();
            lblContractStart = new Label();
            txtContractStart = new TextBox();
            btnAddCompany = new Button();
            SuspendLayout();
            // 
            // listView1
            // 
            listView1.Location = new Point(29, 87);
            listView1.Name = "listView1";
            listView1.Size = new Size(376, 337);
            listView1.TabIndex = 0;
            listView1.UseCompatibleStateImageBehavior = false;
            // 
            // lblCurrentCompanies
            // 
            lblCurrentCompanies.AutoSize = true;
            lblCurrentCompanies.Location = new Point(29, 59);
            lblCurrentCompanies.Name = "lblCurrentCompanies";
            lblCurrentCompanies.Size = new Size(113, 15);
            lblCurrentCompanies.TabIndex = 1;
            lblCurrentCompanies.Text = "Current Companies:";
            // 
            // lblAddCompany
            // 
            lblAddCompany.AutoSize = true;
            lblAddCompany.Location = new Point(493, 59);
            lblAddCompany.Name = "lblAddCompany";
            lblAddCompany.Size = new Size(87, 15);
            lblAddCompany.TabIndex = 2;
            lblAddCompany.Text = "Add Company:";
            // 
            // txtCompanyName
            // 
            txtCompanyName.Location = new Point(568, 98);
            txtCompanyName.Name = "txtCompanyName";
            txtCompanyName.Size = new Size(100, 23);
            txtCompanyName.TabIndex = 3;
            // 
            // lblCompanyName
            // 
            lblCompanyName.AutoSize = true;
            lblCompanyName.Location = new Point(440, 101);
            lblCompanyName.Name = "lblCompanyName";
            lblCompanyName.Size = new Size(97, 15);
            lblCompanyName.TabIndex = 4;
            lblCompanyName.Text = "Company Name:";
            // 
            // lblContractStart
            // 
            lblContractStart.AutoSize = true;
            lblContractStart.Location = new Point(440, 144);
            lblContractStart.Name = "lblContractStart";
            lblContractStart.Size = new Size(110, 15);
            lblContractStart.TabIndex = 5;
            lblContractStart.Text = "Contract Start Date:";
            // 
            // txtContractStart
            // 
            txtContractStart.Location = new Point(568, 136);
            txtContractStart.Name = "txtContractStart";
            txtContractStart.Size = new Size(100, 23);
            txtContractStart.TabIndex = 6;
            // 
            // btnAddCompany
            // 
            btnAddCompany.AutoSize = true;
            btnAddCompany.Location = new Point(509, 176);
            btnAddCompany.Name = "btnAddCompany";
            btnAddCompany.Size = new Size(94, 25);
            btnAddCompany.TabIndex = 7;
            btnAddCompany.Text = "Add Company";
            btnAddCompany.UseVisualStyleBackColor = true;
            // 
            // frmCompanies
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(751, 450);
            Controls.Add(btnAddCompany);
            Controls.Add(txtContractStart);
            Controls.Add(lblContractStart);
            Controls.Add(lblCompanyName);
            Controls.Add(txtCompanyName);
            Controls.Add(lblAddCompany);
            Controls.Add(lblCurrentCompanies);
            Controls.Add(listView1);
            Name = "frmCompanies";
            Text = "frmCompanies";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListView listView1;
        private Label lblCurrentCompanies;
        private Label lblAddCompany;
        private TextBox txtCompanyName;
        private Label lblCompanyName;
        public Label lblContractStart;
        private TextBox txtContractStart;
        private Button btnAddCompany;
    }
}