﻿namespace ExpenseManager
{
    partial class frmCreateAcct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblCreateAcct = new Label();
            lblFirstName = new Label();
            lblLastName = new Label();
            lblUsername = new Label();
            lblPassword = new Label();
            lblEmail = new Label();
            txtFName = new TextBox();
            txtLName = new TextBox();
            txtEmail = new TextBox();
            txtUsername = new TextBox();
            txtPassword = new TextBox();
            btnCreateAcct = new Button();
            lblCAMessage = new Label();
            SuspendLayout();
            // 
            // lblCreateAcct
            // 
            lblCreateAcct.AutoSize = true;
            lblCreateAcct.Location = new Point(145, 43);
            lblCreateAcct.Name = "lblCreateAcct";
            lblCreateAcct.Size = new Size(89, 15);
            lblCreateAcct.TabIndex = 0;
            lblCreateAcct.Text = "Create Account";
            // 
            // lblFirstName
            // 
            lblFirstName.AutoSize = true;
            lblFirstName.Location = new Point(91, 97);
            lblFirstName.Name = "lblFirstName";
            lblFirstName.Size = new Size(67, 15);
            lblFirstName.TabIndex = 1;
            lblFirstName.Text = "First Name:";
            // 
            // lblLastName
            // 
            lblLastName.AutoSize = true;
            lblLastName.Location = new Point(91, 127);
            lblLastName.Name = "lblLastName";
            lblLastName.Size = new Size(66, 15);
            lblLastName.TabIndex = 2;
            lblLastName.Text = "Last Name:";
            // 
            // lblUsername
            // 
            lblUsername.AutoSize = true;
            lblUsername.Location = new Point(91, 193);
            lblUsername.Name = "lblUsername";
            lblUsername.Size = new Size(66, 15);
            lblUsername.TabIndex = 3;
            lblUsername.Text = "Username: ";
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Location = new Point(91, 226);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(60, 15);
            lblPassword.TabIndex = 4;
            lblPassword.Text = "Password:";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(91, 159);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(84, 15);
            lblEmail.TabIndex = 5;
            lblEmail.Text = "Email Address:";
            // 
            // txtFName
            // 
            txtFName.Location = new Point(198, 89);
            txtFName.Name = "txtFName";
            txtFName.Size = new Size(100, 23);
            txtFName.TabIndex = 6;
            // 
            // txtLName
            // 
            txtLName.Location = new Point(198, 119);
            txtLName.Name = "txtLName";
            txtLName.Size = new Size(100, 23);
            txtLName.TabIndex = 7;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(198, 148);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(100, 23);
            txtEmail.TabIndex = 8;
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(198, 185);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(100, 23);
            txtUsername.TabIndex = 9;
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(198, 218);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(100, 23);
            txtPassword.TabIndex = 10;
            // 
            // btnCreateAcct
            // 
            btnCreateAcct.AutoSize = true;
            btnCreateAcct.Location = new Point(135, 286);
            btnCreateAcct.Name = "btnCreateAcct";
            btnCreateAcct.Size = new Size(99, 25);
            btnCreateAcct.TabIndex = 11;
            btnCreateAcct.Text = "Create Account";
            btnCreateAcct.UseVisualStyleBackColor = true;
            btnCreateAcct.Click += btnCreateAcct_Click;
            // 
            // lblCAMessage
            // 
            lblCAMessage.AutoSize = true;
            lblCAMessage.Location = new Point(95, 344);
            lblCAMessage.Name = "lblCAMessage";
            lblCAMessage.Size = new Size(0, 15);
            lblCAMessage.TabIndex = 12;
            // 
            // frmCreateAcct
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(413, 450);
            Controls.Add(lblCAMessage);
            Controls.Add(btnCreateAcct);
            Controls.Add(txtPassword);
            Controls.Add(txtUsername);
            Controls.Add(txtEmail);
            Controls.Add(txtLName);
            Controls.Add(txtFName);
            Controls.Add(lblEmail);
            Controls.Add(lblPassword);
            Controls.Add(lblUsername);
            Controls.Add(lblLastName);
            Controls.Add(lblFirstName);
            Controls.Add(lblCreateAcct);
            Name = "frmCreateAcct";
            Text = "frmCreateAcct";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblCreateAcct;
        private Label lblFirstName;
        private Label lblLastName;
        private Label lblUsername;
        private Label lblPassword;
        private Label lblEmail;
        private TextBox txtFName;
        private TextBox txtLName;
        private TextBox txtEmail;
        private TextBox txtUsername;
        private TextBox txtPassword;
        private Button btnCreateAcct;
        private Label lblCAMessage;
    }
}