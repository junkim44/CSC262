﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using MySqlConnector;
using System.Data;
using System.Security.Cryptography;

namespace ExpenseManager.Data
{
    // using static class since I don't have to instantiate an object, works great with database
    public static class DatabaseHelper
    {
        // create variable taht will hold the connection string info
        private static string expenseDB = ConfigurationManager.ConnectionStrings["expenseDB"].ConnectionString;

        // this method will set up the MariaDB connection - this will be used just by method in this class
        public static MySqlConnection GetConnection()
        {
            return new MySqlConnection(expenseDB);
        }

        // TODO: will need to add methods for queries that I will use often.

        // set up the helper method to return a datatable of the specified query
        public static DataTable ExecuteRead(string sql, Dictionary<string, object> parameters = null)
        {
            // this datatable will magically get the database query results and we will pass it back to the calling code so it can be used in a, for example dgv
            DataTable dt = new DataTable();

            using (MySqlConnection conn = GetConnection())
            {
                conn.Open();

                using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                {
                    // handle the parameters
                    AddParameters(cmd, parameters);

                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(cmd))
                    {
                        adapter.Fill(dt);
                    }
                }
            }

            return dt;
        }

        // set up the helper method to run our "nonqueries" - insert, update, delete
        public static int ExecuteNonQuery(string sql, Dictionary<string, object> parameters = null)
        {
            using (MySqlConnection conn = GetConnection())
            {
                conn.Open();

                using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                {
                    // handle the parameters
                    AddParameters(cmd, parameters);

                    // run the command and then return how many rows were affected
                    return cmd.ExecuteNonQuery();
                }
            }
        }
        // this will add the parameters from the user safely into the database command
        private static void AddParameters(MySqlCommand cmd, Dictionary <string, object> parameters)
        {
            if (parameters == null)
            {
                return;
            }

            // if we get here, parameters were passed in and we need to loop through them
            foreach(var param in parameters)
            {
                cmd.Parameters.AddWithValue(
                    param.Key,
                    param.Value ?? DBNull.Value
                    );
            }
        }
    }
}
