﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExpenseManager.Classes
{
    public abstract class Expense
    {
        // declaring private fields
        private int expenseID;
        private int projectID;
        private string expenseName;
        private string expDescription;
        private DateTime expenseDate;
        private PaymentMethod paidMethod;
        private Receipt exReceipt;

        // getters and setters
        public int ExpenseID { get; set; }
        public int ProjectID { get; set; }
        public string ExpenseName { get; set; }
        public string ExpDescription { get; set; }
        public DateTime ExpenseDate { get; set; }
        public PaymentMethod PaidMethod { get; set; }
        public Receipt ExReceipt { get; set; }

        // constructor
        public Expense(int expenseID, int projectID, string expenseName, string expDescription, DateTime expenseDate, PaymentMethod paidMethod, Receipt exReceipt)
        {
            ExpenseID = expenseID;
            ProjectID = projectID;
            ExpenseName = expenseName;
            ExpDescription = expDescription;
            ExpenseDate = expenseDate;
            PaidMethod = paidMethod;
            ExReceipt = exReceipt;
        }

        // constructor for mileage, since it doesn't need payment method or receipt
        public Expense(int expenseID, int projectID, string expenseName, string expDescription, DateTime expenseDate)
        {
            ExpenseID = expenseID;
            ProjectID = projectID;
            ExpenseName = expenseName;
            ExpDescription = expDescription;
            ExpenseDate = expenseDate;
        }
    }
}
