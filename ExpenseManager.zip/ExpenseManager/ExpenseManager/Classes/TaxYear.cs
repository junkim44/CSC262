﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExpenseManager.Classes
{
 public class TaxYear
    {
        // declaring private fields in class
        private int taxYearID;
        private int year;
        private double fedMileageRate;

        // getters and setters
        public int TaxYearID { get; set; }
        public int Year {  get; set; }
        public double FedMileageRate { get; set; }
        // constructor
        public TaxYear(int taxYearID, int year, double fedMileageRate)
        {
            TaxYearID = taxYearID;
            Year = year;
            FedMileageRate = fedMileageRate;
        }
    }
}
