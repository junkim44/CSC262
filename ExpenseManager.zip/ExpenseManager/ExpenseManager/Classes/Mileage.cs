﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExpenseManager.Classes
{
    public class Mileage : Expense
    {
        // declaring private fields
        private double milesDriven;

        // getters and setters
        public double MilesDriven { get; set;  }

        // constructor, need to inherit from base class
        public Mileage (int expenseID, int projectID, string expenseName, string expDescription, DateTime expenseDate, double milesDriven)
            : base (expenseID, projectID, expenseName, expDescription, expenseDate)
        {
            MilesDriven = milesDriven;
        }
    }
}
