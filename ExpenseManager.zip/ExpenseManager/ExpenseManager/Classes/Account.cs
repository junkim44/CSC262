﻿using ExpenseManager.Data;
using System;
using System.Collections.Generic;
using System.Text;
using MySqlConnector;
using System.Security.Cryptography.X509Certificates;

namespace ExpenseManager.Classes
{
    // Creating class for account
    public class Account
    {
        // declaring private fields/properties of class Account 
        private int accountID;
        private string username;
        private string password;
        private string email;
        private DateTime dateCreated;
     
        // getters and setters, need to make sure I validate username, password, and email
        public int AccountID { get; private set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Email {  get; set; }
        public DateOnly DateCreated { get; private set; }

        // constructor for creating new account
        public Account(string username, string password, string email)
        {
            Username = username;
            Password = password;
            Email = email;
            DateCreated = DateOnly.FromDateTime(DateTime.Today);
        }

        // constructor for accessing user_account table in database
        public Account(int accountID, string username, string password, string email, DateOnly dateCreated)
        {
            AccountID = accountID;
            Username = username;
            Password = password;
            Email = email;
            DateCreated = dateCreated;
        }
        // empty constructor for UserProfile creation
        public Account() { }
        // method for validating login
        public static Account validateLogin(string ipUsername, string ipPassword)
        {
            // query statement for MySQL
            string query = @"SELECT account_id, username, acc_password, email, date_created FROM user_account WHERE username = @ipUsername AND acc_password = @ipPassword;";

            // get connection to database
            using (MySqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ipUsername", ipUsername);
                cmd.Parameters.AddWithValue("@ipPassword", ipPassword);

                // Using data reader to retrieve data from the table
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Account(
                            accountID: reader.GetInt32("account_id"),
                            username: reader.GetString("username"),
                            password: reader.GetString("acc_password"),
                            email: reader.GetString("email"),
                            dateCreated: DateOnly.FromDateTime(reader.GetDateTime("date_created"))
                            );
                    }
                    return null; // if no match is found
                }
            }
        }
        public static int CreateAccount (Account account)
        {
            //// Check if the username exists already
            //if (UsernameExists(username))
            //    throw new Exception("Username is already taken.");
            // query to enter into MySQL workbench
            string query = @"INSERT INTO user_account (username, acc_password, email, date_created) VALUES (@username, @password, @email, @date_created); SELECT LAST_INSERT_ID();"; // this returns the new id

            using (MySqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@username", account.Username);
                cmd.Parameters.AddWithValue("@password", account.Password);
                cmd.Parameters.AddWithValue("@email", account.Email);
                cmd.Parameters.AddWithValue("@date_created", DateTime.Today);

                int newID = Convert.ToInt32(cmd.ExecuteScalar());

                return newID;
            }
        }
        // method for checking if there is same username already
        public static bool UsernameExists(string username)
        {
            // query for the method
            string query = "SELECT COUNT(*) FROM user_account WHERE username = @username";

            using (MySqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@username", username);
                return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
            }
        }
    }
}
