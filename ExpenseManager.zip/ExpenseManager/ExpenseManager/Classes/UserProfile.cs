﻿using ExpenseManager.Data;
using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace ExpenseManager.Classes
{
    // Creating subclass UserProfile from account
    public class UserProfile : Account
    {
        // private fields of class
        private int profileID;
        private string firstName;
        private string lastName;
        // getter and setter methods
        public int ProfileID { get; private set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        // constructor for loading DB
        public UserProfile(int accountID, string username, string password, string email, DateOnly dateCreated, int profileID, string firstName, string lastName)
            : base (accountID, username, password, email, dateCreated)
        {
            ProfileID = profileID;
            FirstName = firstName;
            LastName = lastName;
        }

        // constructor for creating new profile
        public UserProfile(string firstName, string lastName)
            :base ()
        {
            FirstName = firstName;
            LastName = lastName;
        }
        // method for creating profile and inserting it into the table.
        public static void CreateProfile(UserProfile profile, int accountID)
        {
            // query for MySql workbench
            string query = @"INSERT INTO user_profile (account_id, first_name, last_name) VALUES (@accountID, @firstName, @lastName);";

            using (MySqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@accountID", accountID);
                cmd.Parameters.AddWithValue("@firstName", profile.FirstName);
                cmd.Parameters.AddWithValue("@lastName", profile.LastName);
                cmd.ExecuteNonQuery();
            }
        }
    }
}
