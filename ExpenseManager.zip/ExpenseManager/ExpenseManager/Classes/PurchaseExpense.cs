﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExpenseManager.Classes
{
    public class PurchaseExpense : Expense
    {
        // declaring private fields
        private string vendor;
        // getter and setter
        public string Vendor { get; set;  }

        // constructor
        public PurchaseExpense(int expenseID, int projectID, string expenseName, string expDescription, DateTime expenseDate, PaymentMethod paidMethod, Receipt exReceipt, string vendor)
            : base(expenseID, projectID, expenseName, expDescription, expenseDate, paidMethod, exReceipt)
        {
            Vendor = vendor;
        }
    }
}
