﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExpenseManager.Classes
{
    public class PaymentMethod
    {
        // declaring private fields of the class
        private int paymentID;
        private string methodType;
        private bool isReimbursed;

        // getters and setters
        public int PaymentID { get; set; }
        public string MethodType { get; set; }
        public bool IsReimbursed { get; set; }

        // constructor
        public PaymentMethod (int paymentID, string methodType,  bool isReimbursed)
        {
            PaymentID = paymentID;
            MethodType = methodType;
            IsReimbursed = isReimbursed;
        }
    }
}
