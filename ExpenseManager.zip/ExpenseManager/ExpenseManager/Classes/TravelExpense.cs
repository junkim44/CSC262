﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExpenseManager.Classes
{
    public class TravelExpense : Expense
    {
        // declaring private fields
        private string destination;
        private List <string> transportType;

        // getters and setters
        public string Destination { get; set; }
        public List <string> TransportType { get; set; }

        // constructor
        public TravelExpense (int expenseID, int projectID, string expenseName, string expDescription, DateTime expenseDate, PaymentMethod paidMethod, Receipt exReceipt, string destination, List <string> transportType)
            : base (expenseID, projectID, expenseName, expDescription, expenseDate, paidMethod, exReceipt)
        {
            Destination = destination;
            TransportType = transportType;
        }
    }
}
