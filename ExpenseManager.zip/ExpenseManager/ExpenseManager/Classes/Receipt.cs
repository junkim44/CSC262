﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExpenseManager.Classes
{
    public class Receipt
    {
        // declaring private fields of receipt
        private int receiptID;
        private DateOnly date;
        private double amount;
        private double tax;
        private double total;

        // getters and setters
        public int ReceiptID { get; set; }
        public DateOnly Date {  get; set; }
        public double Amount { get; set; }
        public double Tax { get; set; }
        public double Total { get ; set; }

        // constructor, won't take total as a parameter, since total can be calculated using amount and tax
        public Receipt (int receiptID, DateOnly date, double amount, double tax)
        {
            ReceiptID = receiptID;
            Date = date;
            Amount = amount;
            Tax = tax;
            Total = amount + tax;
        }
    }
}
