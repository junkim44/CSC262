﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExpenseManager.Classes
{
    // TODO: think about doing some validations with the class fields
    public class Project
    {
        // declaring private fields of class
        private int projectID;
        private string projectName;
        private string jobTitle;
        private DateTime projectStart;
        // getters and setters
        public int ProjectID { get; set; }
        public string ProjectName { get; set; }
        public string JobTitle { get; set; }
        public DateOnly ProjectStart {  get; set; }

        // constructor for loading from database
        public Project(int projectID, string projectName, string jobTitle, DateOnly projectStart)
        {
            ProjectID = projectID;
            ProjectName = projectName;
            JobTitle = jobTitle;
            ProjectStart = projectStart;
        }

        // constructor for creating a new project
        public Project(string projectName, string jobTitle, DateOnly projectStart)
        {
            ProjectName = projectName;
            JobTitle = jobTitle;
            ProjectStart = projectStart;
        }

        // method for adding Project

    }
}
