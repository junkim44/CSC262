﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExpenseManager.Classes
{
    public class HotelExpense : Expense
    {
        // declaring private fields in the class
        private string hotelName;
        private int numNights;

        // getters and setters
        public string HotelName { get; set;  }
        public int NumNights { get; set;  } 

        // constructor
        public HotelExpense(int expenseID, int projectID, string expenseName, string expDescription, DateTime expenseDate, PaymentMethod paidMethod, Receipt exReceipt, string hotelName, int numNights)
            : base(expenseID, projectID, expenseName, expDescription, expenseDate, paidMethod, exReceipt)
        {
            HotelName = hotelName;
            NumNights = numNights;
        }
    }
}
