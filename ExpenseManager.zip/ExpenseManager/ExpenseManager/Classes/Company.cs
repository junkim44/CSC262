﻿using ExpenseManager.Data;
using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace ExpenseManager.Classes
{
    public class Company
    {
        // declaring private fields of the class
        private int companyID;
        private string companyName;
        private DateTime contractStart;
        // getters and setters
        public int CompanyID { get; set; }
        public string CompanyName { get; set; }
        public DateOnly ContractStart {  get; set; }

        // Constructor for loading from DB
        public Company(int companyID, string companyName, DateOnly contractStart)
        {
            CompanyID = companyID;
            CompanyName = companyName;
            ContractStart = contractStart;
        }
        // constructor for creating new company
        public Company(string companyName, DateOnly contractStart)
        {
            CompanyName = companyName;
            ContractStart = contractStart;
        }

        // method for adding company
        public static void AddCompany(Company company, int profileID)
        {
            // query to add company into DB
            string query = @"INSERT INTO company (profile_id, company_name, contract_start_date) 
                VALUES (@profileID, @companyName, @contractStart);";

            // get connection to database
            using (MySqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@profileID", profileID);
                cmd.Parameters.AddWithValue("@companyName", company.CompanyName);
                cmd.Parameters.AddWithValue("@contractStart", company.ContractStart);
            }
        }
        // method to get company details
        public static List<Company> GetCompByProfile (int profileID)
        {
            // create list to hold results
            List<Company> companies = new List<Company>();

            // query to get the data I want to display
            string query = @"SELECT company_name, contract_start_date FROM company WHERE profile_id = @profileID;";

            // get connection to database
            using (MySqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@profileID", profileID);

                // using data reader to retrieve data from the table
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    // move to each row one at a time
                    while (reader.Read())
                    {
                        companies.Add(new Company(
                            companyID: reader.GetInt32("company_id"),
                            companyName: reader.GetString("company_name"),
                            contractStart: DateOnly.FromDateTime(reader.GetDateTime("contract_start_date"))
                            ));
                    }
                }
            }
            // Return the completed list
            return companies;
        }
        public static void DeleteCompany(int companyID)
        {
            // query to delete company from db
            string query = @"DELETE FROM company WHERE companyID = @companyID;";

            // get connection to database
            using (MySqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@companyID", companyID);
            }
        }
    }
}
