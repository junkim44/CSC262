﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExpenseManager.Classes
{
    public class MealExpense : Expense
    {
        // declaring private fields
        private string restaurant;
        private int numAttendees;

        // getters and setters
        public string Restaurant { get; set;  }
        public int NumAttendees { get; set; }

        // constructor
        public MealExpense(int expenseID, int projectID, string expenseName, string expDescription, DateTime expenseDate, PaymentMethod paidMethod, Receipt exReceipt, string restaurant, int numAttendees)
            : base(expenseID, projectID, expenseName, expDescription, expenseDate, paidMethod, exReceipt)
        {
            Restaurant = restaurant;
            NumAttendees = numAttendees;
        }
    }
}
