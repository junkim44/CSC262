using ExpenseManager.Classes;

namespace ExpenseManager
{
    public partial class frmLogIn : Form
    {
        public frmLogIn()
        {
            InitializeComponent();

        }
        private void btnLogin_Click(object sender, EventArgs e)
        {

            // declare variables for username and password
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            // input validation, make sure the user entered both username and password
            if ((string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password)))
            {
                lblLoginMessage.Text = "Please enter both username and password.";
                return;
            }

            // Try to find the user in database
            Account account = Account.validateLogin(username, password);

            // if the account is found
            if (account != null)
            {
                // welcome message
                lblLoginMessage.Text = $"Welcome back, {account.Username}!"; 

                // open dashboard form after log in has been validated.
                frmDashboard frmDashboard = new frmDashboard();
                frmDashboard.Show();
                this.Hide();
            } else
            {
                lblLoginMessage.Text = $"Invalid username or password, please try again!";
            }
        }

        // event handler for creating account
        private void btnCreateAcct_Click(object sender, EventArgs e)
        {
            frmCreateAcct frmCreateAcct = new frmCreateAcct();
            frmCreateAcct.Show();
            this.Hide();
        }
    }
}
