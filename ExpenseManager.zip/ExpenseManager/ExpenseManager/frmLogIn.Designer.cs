﻿namespace ExpenseManager
{
    partial class frmLogIn
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblWelcomeMessage = new Label();
            lblUsername = new Label();
            txtUsername = new TextBox();
            lblPassword = new Label();
            txtPassword = new TextBox();
            btnLogin = new Button();
            btnCreateAcct = new Button();
            panel1 = new Panel();
            lblLoginMessage = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI Semibold", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitle.ForeColor = Color.FromArgb(89, 131, 146);
            lblTitle.Location = new Point(160, 40);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(151, 37);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "1099Buddy";
            // 
            // lblWelcomeMessage
            // 
            lblWelcomeMessage.AutoSize = true;
            lblWelcomeMessage.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblWelcomeMessage.ForeColor = Color.FromArgb(174, 195, 176);
            lblWelcomeMessage.Location = new Point(46, 88);
            lblWelcomeMessage.Name = "lblWelcomeMessage";
            lblWelcomeMessage.Size = new Size(391, 21);
            lblWelcomeMessage.TabIndex = 1;
            lblWelcomeMessage.Text = "Track every deduction. Keep more of what you earn.";
            // 
            // lblUsername
            // 
            lblUsername.AutoSize = true;
            lblUsername.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblUsername.ForeColor = Color.FromArgb(174, 195, 176);
            lblUsername.Location = new Point(125, 40);
            lblUsername.Name = "lblUsername";
            lblUsername.Size = new Size(86, 20);
            lblUsername.TabIndex = 2;
            lblUsername.Text = "Username: ";
            // 
            // txtUsername
            // 
            txtUsername.BackColor = Color.FromArgb(174, 195, 176);
            txtUsername.BorderStyle = BorderStyle.FixedSingle;
            txtUsername.HideSelection = false;
            txtUsername.Location = new Point(227, 42);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(121, 23);
            txtUsername.TabIndex = 3;
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPassword.ForeColor = Color.FromArgb(174, 195, 176);
            lblPassword.Location = new Point(125, 75);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(77, 20);
            lblPassword.TabIndex = 4;
            lblPassword.Text = "Password:";
            // 
            // txtPassword
            // 
            txtPassword.BackColor = Color.FromArgb(174, 195, 176);
            txtPassword.BorderStyle = BorderStyle.FixedSingle;
            txtPassword.Location = new Point(227, 75);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(121, 23);
            txtPassword.TabIndex = 5;
            // 
            // btnLogin
            // 
            btnLogin.AutoSize = true;
            btnLogin.BackColor = Color.FromArgb(174, 195, 176);
            btnLogin.FlatStyle = FlatStyle.Flat;
            btnLogin.Font = new Font("Segoe UI", 11F);
            btnLogin.ForeColor = Color.FromArgb(1, 22, 30);
            btnLogin.Location = new Point(273, 119);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(75, 32);
            btnLogin.TabIndex = 6;
            btnLogin.Text = "Log In";
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += btnLogin_Click;
            // 
            // btnCreateAcct
            // 
            btnCreateAcct.AutoSize = true;
            btnCreateAcct.BackColor = Color.FromArgb(174, 195, 176);
            btnCreateAcct.FlatStyle = FlatStyle.Flat;
            btnCreateAcct.Font = new Font("Segoe UI", 11F);
            btnCreateAcct.ForeColor = Color.FromArgb(1, 22, 30);
            btnCreateAcct.Location = new Point(125, 119);
            btnCreateAcct.Name = "btnCreateAcct";
            btnCreateAcct.Size = new Size(124, 32);
            btnCreateAcct.TabIndex = 7;
            btnCreateAcct.Text = "Create Account";
            btnCreateAcct.UseVisualStyleBackColor = false;
            btnCreateAcct.Click += btnCreateAcct_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(18, 69, 89);
            panel1.Controls.Add(lblLoginMessage);
            panel1.Controls.Add(btnCreateAcct);
            panel1.Controls.Add(btnLogin);
            panel1.Controls.Add(txtPassword);
            panel1.Controls.Add(lblPassword);
            panel1.Controls.Add(txtUsername);
            panel1.Controls.Add(lblUsername);
            panel1.Location = new Point(0, 125);
            panel1.Name = "panel1";
            panel1.Size = new Size(481, 245);
            panel1.TabIndex = 8;
            // 
            // lblLoginMessage
            // 
            lblLoginMessage.AutoSize = true;
            lblLoginMessage.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblLoginMessage.ForeColor = Color.FromArgb(174, 195, 176);
            lblLoginMessage.Location = new Point(128, 176);
            lblLoginMessage.Name = "lblLoginMessage";
            lblLoginMessage.Size = new Size(0, 17);
            lblLoginMessage.TabIndex = 8;
            // 
            // frmLogIn
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(1, 22, 30);
            ClientSize = new Size(480, 364);
            Controls.Add(panel1);
            Controls.Add(lblWelcomeMessage);
            Controls.Add(lblTitle);
            Name = "frmLogIn";
            Text = "Log In";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitle;
        private Label lblWelcomeMessage;
        private Label lblUsername;
        private TextBox txtUsername;
        private Label lblPassword;
        private TextBox txtPassword;
        private Button btnLogin;
        private Button btnCreateAcct;
        private Panel panel1;
        private Label lblLoginMessage;
    }
}
