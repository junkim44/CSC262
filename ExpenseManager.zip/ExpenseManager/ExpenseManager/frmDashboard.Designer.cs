﻿namespace ExpenseManager
{
    partial class frmDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pnlDash = new Panel();
            btnAddExpense = new Button();
            btnTaxSummary = new Button();
            btnReceipts = new Button();
            btnMileage = new Button();
            btnProjects = new Button();
            btnCompany = new Button();
            btnProfile = new Button();
            pnlHeader = new Panel();
            btnLogOut = new Button();
            lblTitle = new Label();
            cmbCompany = new ComboBox();
            lblCompany = new Label();
            lblProject = new Label();
            cmbProject = new ComboBox();
            dataGridView1 = new DataGridView();
            dataGridView2 = new DataGridView();
            lbl = new Label();
            pnlDash.SuspendLayout();
            pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            SuspendLayout();
            // 
            // pnlDash
            // 
            pnlDash.BackColor = Color.FromArgb(1, 22, 30);
            pnlDash.Controls.Add(btnAddExpense);
            pnlDash.Controls.Add(btnTaxSummary);
            pnlDash.Controls.Add(btnReceipts);
            pnlDash.Controls.Add(btnMileage);
            pnlDash.Controls.Add(btnProjects);
            pnlDash.Controls.Add(btnCompany);
            pnlDash.Controls.Add(btnProfile);
            pnlDash.Location = new Point(0, 45);
            pnlDash.Name = "pnlDash";
            pnlDash.Size = new Size(151, 563);
            pnlDash.TabIndex = 0;
            // 
            // btnAddExpense
            // 
            btnAddExpense.AutoSize = true;
            btnAddExpense.FlatStyle = FlatStyle.Flat;
            btnAddExpense.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAddExpense.ForeColor = Color.FromArgb(174, 195, 176);
            btnAddExpense.Location = new Point(0, 237);
            btnAddExpense.Name = "btnAddExpense";
            btnAddExpense.Size = new Size(149, 32);
            btnAddExpense.TabIndex = 6;
            btnAddExpense.Text = "Add Expense";
            btnAddExpense.UseVisualStyleBackColor = true;
            // 
            // btnTaxSummary
            // 
            btnTaxSummary.AutoSize = true;
            btnTaxSummary.FlatStyle = FlatStyle.Flat;
            btnTaxSummary.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnTaxSummary.ForeColor = Color.FromArgb(174, 195, 176);
            btnTaxSummary.Location = new Point(0, 199);
            btnTaxSummary.Name = "btnTaxSummary";
            btnTaxSummary.Size = new Size(149, 32);
            btnTaxSummary.TabIndex = 5;
            btnTaxSummary.Text = "Tax Summary";
            btnTaxSummary.UseVisualStyleBackColor = true;
            // 
            // btnReceipts
            // 
            btnReceipts.AutoSize = true;
            btnReceipts.FlatStyle = FlatStyle.Flat;
            btnReceipts.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnReceipts.ForeColor = Color.FromArgb(174, 195, 176);
            btnReceipts.Location = new Point(0, 161);
            btnReceipts.Name = "btnReceipts";
            btnReceipts.Size = new Size(149, 32);
            btnReceipts.TabIndex = 4;
            btnReceipts.Text = "Receipts";
            btnReceipts.UseVisualStyleBackColor = true;
            // 
            // btnMileage
            // 
            btnMileage.AutoSize = true;
            btnMileage.FlatStyle = FlatStyle.Flat;
            btnMileage.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnMileage.ForeColor = Color.FromArgb(174, 195, 176);
            btnMileage.Location = new Point(0, 123);
            btnMileage.Name = "btnMileage";
            btnMileage.Size = new Size(149, 32);
            btnMileage.TabIndex = 3;
            btnMileage.Text = "Mileage";
            btnMileage.UseVisualStyleBackColor = true;
            // 
            // btnProjects
            // 
            btnProjects.AutoSize = true;
            btnProjects.FlatStyle = FlatStyle.Flat;
            btnProjects.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnProjects.ForeColor = Color.FromArgb(174, 195, 176);
            btnProjects.Location = new Point(0, 85);
            btnProjects.Name = "btnProjects";
            btnProjects.Size = new Size(149, 32);
            btnProjects.TabIndex = 2;
            btnProjects.Text = "Projects";
            btnProjects.TextAlign = ContentAlignment.TopCenter;
            btnProjects.UseVisualStyleBackColor = true;
            // 
            // btnCompany
            // 
            btnCompany.AutoSize = true;
            btnCompany.FlatStyle = FlatStyle.Flat;
            btnCompany.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCompany.ForeColor = Color.FromArgb(174, 195, 176);
            btnCompany.Location = new Point(0, 47);
            btnCompany.Name = "btnCompany";
            btnCompany.Size = new Size(149, 32);
            btnCompany.TabIndex = 1;
            btnCompany.Text = "Companies";
            btnCompany.TextAlign = ContentAlignment.TopCenter;
            btnCompany.UseVisualStyleBackColor = true;
            btnCompany.Click += btnCompany_Click;
            // 
            // btnProfile
            // 
            btnProfile.AutoSize = true;
            btnProfile.FlatStyle = FlatStyle.Flat;
            btnProfile.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnProfile.ForeColor = Color.FromArgb(174, 195, 176);
            btnProfile.Location = new Point(0, 9);
            btnProfile.Name = "btnProfile";
            btnProfile.Size = new Size(149, 32);
            btnProfile.TabIndex = 0;
            btnProfile.Text = "Profile";
            btnProfile.UseVisualStyleBackColor = true;
            // 
            // pnlHeader
            // 
            pnlHeader.BackColor = Color.FromArgb(1, 22, 30);
            pnlHeader.Controls.Add(btnLogOut);
            pnlHeader.Controls.Add(lblTitle);
            pnlHeader.Location = new Point(-5, -2);
            pnlHeader.Name = "pnlHeader";
            pnlHeader.Size = new Size(1090, 50);
            pnlHeader.TabIndex = 1;
            // 
            // btnLogOut
            // 
            btnLogOut.BackgroundImageLayout = ImageLayout.None;
            btnLogOut.FlatStyle = FlatStyle.Flat;
            btnLogOut.Font = new Font("Segoe UI", 10F);
            btnLogOut.ForeColor = Color.FromArgb(174, 195, 176);
            btnLogOut.Location = new Point(967, 11);
            btnLogOut.Name = "btnLogOut";
            btnLogOut.Size = new Size(103, 30);
            btnLogOut.TabIndex = 1;
            btnLogOut.Text = "Logout";
            btnLogOut.UseVisualStyleBackColor = true;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitle.ForeColor = Color.FromArgb(174, 195, 176);
            lblTitle.Location = new Point(17, 11);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(132, 32);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "1099Buddy";
            // 
            // cmbCompany
            // 
            cmbCompany.FormattingEnabled = true;
            cmbCompany.Location = new Point(268, 63);
            cmbCompany.Name = "cmbCompany";
            cmbCompany.Size = new Size(121, 23);
            cmbCompany.TabIndex = 2;
            // 
            // lblCompany
            // 
            lblCompany.AutoSize = true;
            lblCompany.Location = new Point(200, 66);
            lblCompany.Name = "lblCompany";
            lblCompany.Size = new Size(62, 15);
            lblCompany.TabIndex = 3;
            lblCompany.Text = "Company:";
            // 
            // lblProject
            // 
            lblProject.AutoSize = true;
            lblProject.Location = new Point(456, 66);
            lblProject.Name = "lblProject";
            lblProject.Size = new Size(47, 15);
            lblProject.TabIndex = 4;
            lblProject.Text = "Project:";
            // 
            // cmbProject
            // 
            cmbProject.FormattingEnabled = true;
            cmbProject.Location = new Point(518, 63);
            cmbProject.Name = "cmbProject";
            cmbProject.Size = new Size(121, 23);
            cmbProject.TabIndex = 5;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(174, 130);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(643, 464);
            dataGridView1.TabIndex = 6;
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(845, 130);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.Size = new Size(220, 464);
            dataGridView2.TabIndex = 7;
            // 
            // lbl
            // 
            lbl.AutoSize = true;
            lbl.Location = new Point(174, 112);
            lbl.Name = "lbl";
            lbl.Size = new Size(38, 15);
            lbl.TabIndex = 8;
            lbl.Text = "label1";
            // 
            // frmDashboard
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(18, 69, 89);
            ClientSize = new Size(1077, 606);
            Controls.Add(lbl);
            Controls.Add(dataGridView2);
            Controls.Add(dataGridView1);
            Controls.Add(cmbProject);
            Controls.Add(lblProject);
            Controls.Add(lblCompany);
            Controls.Add(cmbCompany);
            Controls.Add(pnlHeader);
            Controls.Add(pnlDash);
            Name = "frmDashboard";
            Text = "frmDashboard";
            pnlDash.ResumeLayout(false);
            pnlDash.PerformLayout();
            pnlHeader.ResumeLayout(false);
            pnlHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel pnlDash;
        private Button btnProfile;
        private Button btnMileage;
        private Button btnProjects;
        private Button btnCompany;
        private Button btnTaxSummary;
        private Button btnReceipts;
        private Panel pnlHeader;
        private Label lblTitle;
        private Button btnLogOut;
        private Button btnAddExpense;
        private ComboBox cmbCompany;
        private Label lblCompany;
        private Label lblProject;
        private ComboBox cmbProject;
        private DataGridView dataGridView1;
        private DataGridView dataGridView2;
        private Label lbl;
    }
}