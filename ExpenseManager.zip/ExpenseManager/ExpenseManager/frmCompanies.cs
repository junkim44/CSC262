﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ExpenseManager
{
    public partial class frmCompanies : Form
    {
        public frmCompanies()
        {
            InitializeComponent();
        }
    }
}
