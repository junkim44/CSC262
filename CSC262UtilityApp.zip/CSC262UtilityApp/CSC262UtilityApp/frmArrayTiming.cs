﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CSC262UtilityApp
{
    public partial class frmArrayTiming : Form
    {
        public frmArrayTiming()
        {
            InitializeComponent();
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            // get the value that the user entered
            string input = txtItems.Text;

            // check if the user entered nothing
            if (input == "")
            {
                lblMessage.Text = "Please enter a number";
                return;
            }

            // check if the user entered a number
            if (!int.TryParse(input, out int size))
            {
                lblMessage.Text = "Please enter a whole number";
                return;
            }

            // create an array based on the number the user entered
            int[] arrNumbers = new int[size];

            // create a random object so that we can generate random numbers
            Random random = new Random();

            // create a stopwatch object so that we can time how long our code takes to run
            Stopwatch timer = new Stopwatch();

            // start the timer
            timer.Start();

            // loop to fill the array with random numbers
            for (int i = 0; i < size; i++)
            {
                // decide what range you want your random numbers to fall within
                arrNumbers[i] = random.Next(1, 10000);
            }

            // stop the timer
            timer.Stop();

            // show user how long it took to run the array generation
            double genTime = timer.ElapsedMilliseconds;

            lblGenTime.Text = $"Generation Time: {genTime,4:F6} ms";

            // reset the timer for the sorting operation
            timer.Reset();

            // start timing the sort
            timer.Start();

            // this will sort the array in numeric order
            Array.Sort(arrNumbers);

            // stop the timer
            timer.Stop();


            // show user how long it took to sort the array
            double sortTime = timer.ElapsedMilliseconds;

            lblSortTime.Text = $"Sort Time: {sortTime,4:F6} ms";
        }
    }
}
