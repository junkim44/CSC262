using System.Diagnostics;

namespace CSC262UtilityApp
{
    public partial class frmAssert : Form
    {
        public frmAssert()
        {
            InitializeComponent();
        }
        private void btnRunAssert_Click(object sender, EventArgs e)
        {
            // 2 variables to hold the values were entered
            string gamerTag = txtGamerTag.Text;
            string health = txtHealth.Text;

            if (gamerTag.Length == 0)
            {
                return;
            }
            
            
            // Exceptions - runtime errors (things that we want our programs to handle) - we must handle these

            // Debug.Assert (What we are doing for assignment) - helps us find logic errors in our program
            // if assert triggers, you need to fix the problem. This only triggers in Debug mode

            // Trace.Assert - you can use traces for logging
            // triggers in either Debug or Release mode

            // if no gamer tag was entered, then this assert will trigger and you will see the message
            // the trigger only fires if the condition tests false
            // if the condition tests true, the compiler skips over the line of code
            Debug.Assert(gamerTag.Length > 0, "Gamer tag cannot be empty"); // needs bool condition and message
            // do another assert for health
        }
    }
}
