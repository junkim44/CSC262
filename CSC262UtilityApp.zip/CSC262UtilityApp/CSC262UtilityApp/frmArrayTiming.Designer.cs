﻿namespace CSC262UtilityApp
{
    partial class frmArrayTiming
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtItems = new TextBox();
            lblItems = new Label();
            lblGenTime = new Label();
            lblSortTime = new Label();
            btnTest = new Button();
            lblMessage = new Label();
            SuspendLayout();
            // 
            // txtItems
            // 
            txtItems.Location = new Point(336, 121);
            txtItems.Name = "txtItems";
            txtItems.Size = new Size(100, 23);
            txtItems.TabIndex = 0;
            // 
            // lblItems
            // 
            lblItems.AutoSize = true;
            lblItems.Location = new Point(226, 124);
            lblItems.Name = "lblItems";
            lblItems.Size = new Size(84, 15);
            lblItems.TabIndex = 1;
            lblItems.Text = "Enter Number:";
            // 
            // lblGenTime
            // 
            lblGenTime.AutoSize = true;
            lblGenTime.Location = new Point(226, 211);
            lblGenTime.Name = "lblGenTime";
            lblGenTime.Size = new Size(61, 15);
            lblGenTime.TabIndex = 2;
            lblGenTime.Text = "Gen Time:";
            // 
            // lblSortTime
            // 
            lblSortTime.AutoSize = true;
            lblSortTime.Location = new Point(402, 211);
            lblSortTime.Name = "lblSortTime";
            lblSortTime.Size = new Size(61, 15);
            lblSortTime.TabIndex = 3;
            lblSortTime.Text = "Sort Time:";
            // 
            // btnTest
            // 
            btnTest.Location = new Point(343, 168);
            btnTest.Name = "btnTest";
            btnTest.Size = new Size(75, 23);
            btnTest.TabIndex = 4;
            btnTest.Text = "Test";
            btnTest.UseVisualStyleBackColor = true;
            btnTest.Click += btnTest_Click;
            // 
            // lblMessage
            // 
            lblMessage.AutoSize = true;
            lblMessage.Location = new Point(308, 86);
            lblMessage.Name = "lblMessage";
            lblMessage.Size = new Size(155, 15);
            lblMessage.TabIndex = 5;
            lblMessage.Text = "Welcome to my timing app!";
            // 
            // frmArrayTiming
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblMessage);
            Controls.Add(btnTest);
            Controls.Add(lblSortTime);
            Controls.Add(lblGenTime);
            Controls.Add(lblItems);
            Controls.Add(txtItems);
            Name = "frmArrayTiming";
            Text = "frmArrayTiming";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtItems;
        private Label lblItems;
        private Label lblGenTime;
        private Label lblSortTime;
        private Button btnTest;
        private Label lblMessage;
    }
}