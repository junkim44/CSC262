﻿namespace CSC262UtilityApp
{
    partial class frmAssert
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtGamerTag = new TextBox();
            txtHealth = new TextBox();
            lblGamerTag = new Label();
            lblHealth = new Label();
            btnRunAssert = new Button();
            SuspendLayout();
            // 
            // txtGamerTag
            // 
            txtGamerTag.Location = new Point(407, 161);
            txtGamerTag.Name = "txtGamerTag";
            txtGamerTag.Size = new Size(186, 23);
            txtGamerTag.TabIndex = 0;
            // 
            // txtHealth
            // 
            txtHealth.Location = new Point(407, 202);
            txtHealth.Name = "txtHealth";
            txtHealth.Size = new Size(186, 23);
            txtHealth.TabIndex = 1;
            // 
            // lblGamerTag
            // 
            lblGamerTag.AutoSize = true;
            lblGamerTag.Location = new Point(337, 164);
            lblGamerTag.Name = "lblGamerTag";
            lblGamerTag.Size = new Size(64, 15);
            lblGamerTag.TabIndex = 2;
            lblGamerTag.Text = "Gamer Tag";
            // 
            // lblHealth
            // 
            lblHealth.AutoSize = true;
            lblHealth.Location = new Point(337, 205);
            lblHealth.Name = "lblHealth";
            lblHealth.Size = new Size(42, 15);
            lblHealth.TabIndex = 3;
            lblHealth.Text = "Health";
            // 
            // btnRunAssert
            // 
            btnRunAssert.Location = new Point(518, 240);
            btnRunAssert.Name = "btnRunAssert";
            btnRunAssert.Size = new Size(75, 23);
            btnRunAssert.TabIndex = 4;
            btnRunAssert.Text = "Run Test";
            btnRunAssert.UseVisualStyleBackColor = true;
            btnRunAssert.Click += this.btnRunAssert_Click;
            // 
            // frmAssert
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnRunAssert);
            Controls.Add(lblHealth);
            Controls.Add(lblGamerTag);
            Controls.Add(txtHealth);
            Controls.Add(txtGamerTag);
            Name = "frmAssert";
            Text = "Assert Example";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtGamerTag;
        private TextBox txtHealth;
        private Label lblGamerTag;
        private Label lblHealth;
        private Button btnRunAssert;
    }
}
