﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VideoGameProgram.Classes
{
    public class Mage : Character
    {
        // the shortcut way of creating the getter and setter methods - if you don't need to do any validation
        public int Mana { get; set; }
        public List<string> Spells { get; set; }
        public Mage(string name, int health, List<string> inventory, int attack, int speed, int defense, int mana, List<string> spells) :
            base(name, health, inventory, attack, speed, defense)
        {
            Mana = mana;
            Spells = spells;
        }
    }
}
