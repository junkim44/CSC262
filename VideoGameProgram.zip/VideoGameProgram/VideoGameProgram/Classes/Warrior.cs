﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VideoGameProgram.Classes
{
    // define the subclass and add : Character so Warrior can use all of the features of the Character class
    public class Warrior : Character
    {
        // the shortcut way of creating the getter and setter methods - if you don't need to do any validation
        public int Power { get; set; }

        public Warrior (string name, int health, List<string> inventory, int attack, int speed, int defense, int power) : 
            base(name, health, inventory, attack, speed, defense)
        {
            // we only need to set the power value here because we call the Character constructor with the base() line of code
            Power = power;
        }

        public string PowerBoost(int morePower)
        {
            Power += morePower;

            return $"{Name} now has {Power}";
        }

    }
}
