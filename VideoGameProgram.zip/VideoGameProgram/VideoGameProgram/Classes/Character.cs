﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VideoGameProgram.Classes
{
    public class Character
    {
        // Private local variables
        private string name; // for private properties, use lowercase for the variable name and for public, use capital for the variable name
        private int health;
        private List<string> inventory;
        private int attack;
        private int speed;
        private int defense;

        // public properties
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int Health
        {
            get { return health;}
            set { 
                // in the set, we can add our data protection rules so that we don't end up
                // with invalid data set on our properties
                    if (value >= 0)
                    {
                        health = value;
                    }
                }
        }

        public List<string> Inventory
        {
            get { return inventory; }
            set { inventory = value; }
        }
        public int Attack
        {
            get { return attack; }
            set { attack = value; }
        }
        public int Speed
        {
            get { return speed; }
            set { speed = value; }
        }
        public int Defense
        {
            get { return defense; }
            set { defense = value; }
        }

        // the C# property set up shortcut
        //public string Middle_Name { get; set; }

        // build the constructor - this allows us to quickly create a Character object
        public Character(string name, int health, List<string> inventory, int attack, int speed, int defense)
        {
            // change the value of the local class variable to the value passed into the constructor
            Name = name; // this is the style that you will see most commonly in existing code bases
            // you can also name the variables in constructor something different like new_name, to make it easier to keep track
            Health = health; // you can set up the object to use the property so you get the data protection
            // this.health = heatlh can be done as well, but you lose the check to see if health is 0 or more
            Inventory = inventory;
            Attack = attack;
            Speed = speed;
            Defense = defense;
        }

        //public Character(string name, int health, int attack, int speed, int defense)
        //{
        //    // change the value of the local class variable to the value passed into the constructor
        //    Name = name; // this is the style that you will see most commonly in existing code bases
        //    // you can also name the variables in constructor something different like new_name, to make it easier to keep track
        //    Health = health; // you can set up the object to use the property so you get the data protection
        //    // this.health = heatlh can be done as well, but you lose the check to see if health is 0 or more
        //    Inventory = inventory;
        //    Attack = attack;
        //    Speed = speed;
        //    Defense = defense;
        //}

        public string Battle(bool hitLanded, int damage)
        {
            // if the hit was successful, then reduce the health
            if (hitLanded)
            {
                Health = Health - damage;
            }
            return $"Health is now {Health}";
        }

        public string Display()
        {
            // TODO : should we add inventory or should we make it a separate method
            return $"Character: {Name} has {Health} health with {Attack} Attack, {Speed} Speed, and {Defense} Defense";
        }
    }
}
