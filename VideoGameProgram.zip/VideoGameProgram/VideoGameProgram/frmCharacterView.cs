using VideoGameProgram.Classes;

namespace VideoGameProgram
{
    public partial class frmCharacterView : Form
    {
        public frmCharacterView()
        {
            InitializeComponent();
        }
        // create a list to hold the character objects that have been created
        private List<Character> existingCharacters = new List<Character>();

        private void btnCreate_Click(object sender, EventArgs e)
        {
            string charName = txtName.Text;
            // (int) is a quick conversion to int from decimal,
            // because the default data type for numericalUpDown is Decimal
            int health = (int)numHealth.Value;

            // take the inventory string and convert to an array and then a list
            List<string> inventory = txtInventory.Text.Split(',').ToList();

            int attack = (int)numAttack.Value;
            int speed = (int)numSpeed.Value;
            int defense = (int)numDefense.Value;

            // now that we have the values and did any validation that we deem necessary
            Character newCharacter = new Character(charName, health, inventory, attack, speed, defense);

            // add the new character to the list of existing characters
            existingCharacters.Add(newCharacter);

            // reload the listbox with our new character added
            LoadCharacterList();

            // Create a warrior
            Warrior newWarrior = new Warrior(charName, health, inventory, attack, speed, defense, 10);

            // create a mage
            Mage newMage = new Mage(charName, health, inventory, attack, speed, defense, 100, inventory);

            lblCharacterInfo.Text = newWarrior.Display();
        }

        // create a method to load the existing characters into the character listbox
        private void LoadCharacterList()
        {
            // clear out any existing characters in the listbox to avoid duplication
            lbCharacters.Items.Clear();

            // loop through the list of characters and add them to the character listbox
            foreach (Character character in existingCharacters)
            {
                // add to listbox
                lbCharacters.Items.Add(character.Display());
            }
        }

        private void lbCharacters_SelectedIndexChanged(object sender, EventArgs e)
        {
            // remove any items currently displayed in inventory list
            lbInventory.Items.Clear();
            // selected index of the listbox will be a value from 0 to the number of characters in the listbox - 1
            // that index correlates with the index of our existing characters in the existing character list
            Character selCharacter = existingCharacters[lbCharacters.SelectedIndex];
            
            // let the user know that the character has no inventory
            if (selCharacter.Inventory.Count == 0)
            {
                lbInventory.Items.Add("Character has no items");
            }
            // the character has inventory so we will display it
            else
            {
                // loop through the string list and display the item in the inventory listbox
                foreach(string item in selCharacter.Inventory)
                {
                    // show item and remove any starting or ending spaces around the item
                    lbInventory.Items.Add(item.Trim());
                }
            }
        }
    }
}
