﻿namespace VideoGameProgram
{
    partial class frmCharacterView
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCreate = new Button();
            lblCharacterInfo = new Label();
            lblName = new Label();
            lblHealth = new Label();
            lblInventory = new Label();
            lblAttack = new Label();
            lblSpeed = new Label();
            txtName = new TextBox();
            lblDefense = new Label();
            txtInventory = new TextBox();
            numHealth = new NumericUpDown();
            numAttack = new NumericUpDown();
            numSpeed = new NumericUpDown();
            numDefense = new NumericUpDown();
            lbCharacters = new ListBox();
            lbInventory = new ListBox();
            lblCharacter = new Label();
            lblCharacterInventory = new Label();
            panel1 = new Panel();
            panel2 = new Panel();
            ((System.ComponentModel.ISupportInitialize)numHealth).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numAttack).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numSpeed).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numDefense).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // btnCreate
            // 
            btnCreate.Location = new Point(40, 252);
            btnCreate.Name = "btnCreate";
            btnCreate.Size = new Size(132, 29);
            btnCreate.TabIndex = 0;
            btnCreate.Text = "Create";
            btnCreate.UseVisualStyleBackColor = true;
            btnCreate.Click += btnCreate_Click;
            // 
            // lblCharacterInfo
            // 
            lblCharacterInfo.AutoSize = true;
            lblCharacterInfo.Location = new Point(135, 368);
            lblCharacterInfo.Name = "lblCharacterInfo";
            lblCharacterInfo.Size = new Size(0, 15);
            lblCharacterInfo.TabIndex = 1;
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(40, 21);
            lblName.Name = "lblName";
            lblName.Size = new Size(39, 15);
            lblName.TabIndex = 2;
            lblName.Text = "Name";
            // 
            // lblHealth
            // 
            lblHealth.AutoSize = true;
            lblHealth.Location = new Point(40, 59);
            lblHealth.Name = "lblHealth";
            lblHealth.Size = new Size(42, 15);
            lblHealth.TabIndex = 3;
            lblHealth.Text = "Health";
            // 
            // lblInventory
            // 
            lblInventory.AutoSize = true;
            lblInventory.Location = new Point(40, 97);
            lblInventory.Name = "lblInventory";
            lblInventory.Size = new Size(57, 15);
            lblInventory.TabIndex = 4;
            lblInventory.Text = "Inventory";
            // 
            // lblAttack
            // 
            lblAttack.AutoSize = true;
            lblAttack.Location = new Point(40, 137);
            lblAttack.Name = "lblAttack";
            lblAttack.Size = new Size(41, 15);
            lblAttack.TabIndex = 5;
            lblAttack.Text = "Attack";
            // 
            // lblSpeed
            // 
            lblSpeed.AutoSize = true;
            lblSpeed.Location = new Point(40, 174);
            lblSpeed.Name = "lblSpeed";
            lblSpeed.Size = new Size(39, 15);
            lblSpeed.TabIndex = 6;
            lblSpeed.Text = "Speed";
            // 
            // txtName
            // 
            txtName.Location = new Point(118, 18);
            txtName.Name = "txtName";
            txtName.Size = new Size(100, 23);
            txtName.TabIndex = 7;
            // 
            // lblDefense
            // 
            lblDefense.AutoSize = true;
            lblDefense.Location = new Point(40, 215);
            lblDefense.Name = "lblDefense";
            lblDefense.Size = new Size(49, 15);
            lblDefense.TabIndex = 8;
            lblDefense.Text = "Defense";
            // 
            // txtInventory
            // 
            txtInventory.Location = new Point(118, 94);
            txtInventory.Name = "txtInventory";
            txtInventory.Size = new Size(100, 23);
            txtInventory.TabIndex = 9;
            // 
            // numHealth
            // 
            numHealth.Location = new Point(118, 59);
            numHealth.Name = "numHealth";
            numHealth.Size = new Size(100, 23);
            numHealth.TabIndex = 10;
            // 
            // numAttack
            // 
            numAttack.Location = new Point(118, 135);
            numAttack.Name = "numAttack";
            numAttack.Size = new Size(100, 23);
            numAttack.TabIndex = 11;
            // 
            // numSpeed
            // 
            numSpeed.Location = new Point(118, 172);
            numSpeed.Name = "numSpeed";
            numSpeed.Size = new Size(100, 23);
            numSpeed.TabIndex = 12;
            // 
            // numDefense
            // 
            numDefense.Location = new Point(118, 213);
            numDefense.Name = "numDefense";
            numDefense.Size = new Size(100, 23);
            numDefense.TabIndex = 13;
            // 
            // lbCharacters
            // 
            lbCharacters.FormattingEnabled = true;
            lbCharacters.Location = new Point(10, 29);
            lbCharacters.Name = "lbCharacters";
            lbCharacters.Size = new Size(489, 109);
            lbCharacters.TabIndex = 14;
            lbCharacters.SelectedIndexChanged += lbCharacters_SelectedIndexChanged;
            // 
            // lbInventory
            // 
            lbInventory.FormattingEnabled = true;
            lbInventory.Location = new Point(10, 178);
            lbInventory.Name = "lbInventory";
            lbInventory.Size = new Size(245, 109);
            lbInventory.TabIndex = 15;
            // 
            // lblCharacter
            // 
            lblCharacter.AutoSize = true;
            lblCharacter.Location = new Point(10, 6);
            lblCharacter.Name = "lblCharacter";
            lblCharacter.Size = new Size(63, 15);
            lblCharacter.TabIndex = 16;
            lblCharacter.Text = "Characters";
            // 
            // lblCharacterInventory
            // 
            lblCharacterInventory.AutoSize = true;
            lblCharacterInventory.Location = new Point(10, 149);
            lblCharacterInventory.Name = "lblCharacterInventory";
            lblCharacterInventory.Size = new Size(119, 15);
            lblCharacterInventory.TabIndex = 17;
            lblCharacterInventory.Text = "Character's Inventory";
            // 
            // panel1
            // 
            panel1.Controls.Add(numDefense);
            panel1.Controls.Add(numSpeed);
            panel1.Controls.Add(numAttack);
            panel1.Controls.Add(numHealth);
            panel1.Controls.Add(txtInventory);
            panel1.Controls.Add(lblDefense);
            panel1.Controls.Add(txtName);
            panel1.Controls.Add(lblSpeed);
            panel1.Controls.Add(lblAttack);
            panel1.Controls.Add(lblInventory);
            panel1.Controls.Add(lblHealth);
            panel1.Controls.Add(lblName);
            panel1.Controls.Add(btnCreate);
            panel1.Location = new Point(24, 41);
            panel1.Name = "panel1";
            panel1.Size = new Size(233, 297);
            panel1.TabIndex = 18;
            // 
            // panel2
            // 
            panel2.Controls.Add(lblCharacterInventory);
            panel2.Controls.Add(lblCharacter);
            panel2.Controls.Add(lbInventory);
            panel2.Controls.Add(lbCharacters);
            panel2.Location = new Point(272, 41);
            panel2.Name = "panel2";
            panel2.Size = new Size(516, 297);
            panel2.TabIndex = 19;
            // 
            // frmCharacterView
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(lblCharacterInfo);
            Name = "frmCharacterView";
            Text = "Manage Video Game Characters";
            ((System.ComponentModel.ISupportInitialize)numHealth).EndInit();
            ((System.ComponentModel.ISupportInitialize)numAttack).EndInit();
            ((System.ComponentModel.ISupportInitialize)numSpeed).EndInit();
            ((System.ComponentModel.ISupportInitialize)numDefense).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCreate;
        private Label lblCharacterInfo;
        private Label lblName;
        private Label lblHealth;
        private Label lblInventory;
        private Label lblAttack;
        private Label lblSpeed;
        private TextBox txtName;
        private Label lblDefense;
        private TextBox txtInventory;
        private NumericUpDown numHealth;
        private NumericUpDown numAttack;
        private NumericUpDown numSpeed;
        private NumericUpDown numDefense;
        private ListBox lbCharacters;
        private ListBox lbInventory;
        private Label lblCharacter;
        private Label lblCharacterInventory;
        private Panel panel1;
        private Panel panel2;
    }
}
